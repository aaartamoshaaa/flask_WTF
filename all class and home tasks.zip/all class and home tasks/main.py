from flask import Flask, render_template, redirect
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)

app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

IMG_PATH = 'static/img/'

professons = {
    'врач': {
        'name': 'medic',
        'sim': 'science_sim',
    },

    'инженер': {
        'name': 'engineer',
        'sim': 'engineer_sim',
    },

    'строитель': {
        'name': 'builder',
        'sim': 'engineer_sim',
    },

    'учёный': {
        'name': 'scientist',
        'sim': 'science_sim',
    },

    'пилот': {
        'name': 'pilot',
        'sim': 'regular',
    }
}

simulators = {
    'science_sim': {
        'name': 'Научные симуляторы',
        'img': IMG_PATH + 'science_sim1.jpg'
    },

    'engineer_sim': {
        'name': 'Инженерные тренажеры',
        'img': IMG_PATH + 'engineer_sim.png'
    },

    'regular': {
        'name': 'Обычные тренажеры',
        'img': IMG_PATH + 'regular_sim.png'
    }
}

default_answer = {
    'title': '',
    'surname': 'Watny',
    'name': 'Mark',
    'education': 'выше среднего',
    'profession': 'пилот',
    'sex': 'male',
    'motivation': 'Всегда мечтал застрять на Марсе!',
    'ready': 'True',
}


class LoginForm(FlaskForm):
    astronaut_id = StringField('id астронавта', validators=[DataRequired()])
    password = PasswordField('пароль астронавта', validators=[DataRequired()])
    captain_id = StringField('id капитана', validators=[DataRequired()])
    captain_password = PasswordField('пароль капитана', validators=[DataRequired()])
    submit = SubmitField('Доступ')


@app.route('/')
@app.route('/index')
def index():
    return render_template('base.html', title='Домашняя страница')


@app.route('/training/<prof>')
def training(prof: str):
    if prof.lower() in professons:
        profession = professons[prof.lower()]
        sim = simulators.get(profession['sim'], simulators['regular'])
    else:
        sim = simulators['regular']

    return render_template('training.html',
                           title='Тренировки в полёте',
                           sim_name=sim['name'],
                           img_source=sim['img'])


@app.route('/list_prof/<lst>')
def list_prof(lst):
    return render_template('list_prof.html',
                           title='Список профессий',
                           list=lst,
                           prof_list=list(professons.keys()))


@app.route('/answer')
@app.route('/auto_answer')
def auto_answer():
    return render_template('auto_answer.html',
                           title='Автоматический ответ',
                           answer_data=default_answer)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        return redirect('/')
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/distribution')
def distribution():
    crew = ['Ридли Скот', 'Марк Уотни', 'Энди Уир']
    return render_template('distribution.html',
                           title='распределение по каютам',
                           crew=crew)


@app.route('/table/<gender>/<age>')
def table_room(gender, age):
    age = int(age)
    if gender.lower() == 'male':
        color = 'blue'
    else:
        color = 'pink'

    if age >= 21:
        img = IMG_PATH + 'adult.png'
    else:
        img = IMG_PATH + 'small.png'

    return render_template('table.html', color=color, img_sorce=IMG_PATH + img)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1', debug=True)
